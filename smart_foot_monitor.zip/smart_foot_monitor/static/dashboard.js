const ZONES = ["heel", "medial_mid", "lateral_mid", "mt1", "mt2", "mt3", "mt4", "mt5"];
const ZONE_LABELS_AR = {
  heel: "كعب", medial_mid: "وسط-داخلي", lateral_mid: "وسط-خارجي",
  mt1: "1", mt2: "2", mt3: "3", mt4: "4", mt5: "5",
};
// إحداثيات تقريبية لشكل القدم (viewBox 200x400)
const ZONE_POS = {
  mt1: [60, 45], mt2: [85, 35], mt3: [110, 35], mt4: [135, 45], mt5: [155, 65],
  medial_mid: [70, 190], lateral_mid: [140, 190],
  heel: [105, 330],
};
const LEVEL_CLASS = { 0: "normal", 1: "watch", 2: "high" };

function buildFootSvg(svgEl) {
  svgEl.innerHTML = "";
  const outline = document.createElementNS("http://www.w3.org/2000/svg", "ellipse");
  outline.setAttribute("cx", 105); outline.setAttribute("cy", 190);
  outline.setAttribute("rx", 75); outline.setAttribute("ry", 175);
  outline.setAttribute("fill", "#101d33"); outline.setAttribute("stroke", "#233256");
  svgEl.appendChild(outline);

  ZONES.forEach(zone => {
    const [cx, cy] = ZONE_POS[zone];
    const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    circle.setAttribute("cx", cx); circle.setAttribute("cy", cy);
    circle.setAttribute("r", 16);
    circle.setAttribute("class", "zone-circle normal");
    circle.setAttribute("id", `zone-${svgEl.id}-${zone}`);
    svgEl.appendChild(circle);

    const label = document.createElementNS("http://www.w3.org/2000/svg", "text");
    label.setAttribute("x", cx); label.setAttribute("y", cy + 4);
    label.setAttribute("class", "zone-label");
    label.textContent = ZONE_LABELS_AR[zone];
    svgEl.appendChild(label);
  });
}

function populateZoneSelect() {
  const sel = document.getElementById("zoneSelect");
  ZONES.forEach(zone => {
    const opt = document.createElement("option");
    opt.value = zone; opt.textContent = ZONE_LABELS_AR[zone] + ` (${zone})`;
    sel.appendChild(opt);
  });
  sel.value = "mt3"; // نبدأ بالمنطقة اللي فيها السيناريو التجريبي
}

let tempChart;
function buildChart() {
  const ctx = document.getElementById("tempChart").getContext("2d");
  tempChart = new Chart(ctx, {
    type: "line",
    data: { labels: [], datasets: [
      { label: "شمال", data: [], borderColor: "#3aa0ff", tension: .3, pointRadius: 0 },
      { label: "يمين", data: [], borderColor: "#e74c3c", tension: .3, pointRadius: 0 },
    ]},
    options: {
      responsive: true,
      scales: {
        x: { ticks: { color: "#8a97b3", maxTicksLimit: 6 } },
        y: { ticks: { color: "#8a97b3" }, title: { display: true, text: "°C", color: "#8a97b3" } },
      },
      plugins: { legend: { labels: { color: "#c7d2e8" } } },
    },
  });
}

async function refreshHeatmaps() {
  try {
    const res = await fetch("/api/latest");
    const data = await res.json();
    document.getElementById("statusDot").classList.add("live");
    document.getElementById("statusText").textContent = "متصل — بيستقبل بيانات حية";

    ["left", "right"].forEach(foot => {
      const svgId = foot === "left" ? "svg-left" : "svg-right";
      const reading = data.reading[foot] || {};
      ZONES.forEach(zone => {
        const circle = document.getElementById(`zone-${svgId}-${zone}`);
        if (!circle || !reading[zone]) return;
        const level = reading[zone].level;
        circle.setAttribute("class", `zone-circle ${LEVEL_CLASS[level]}`);
        circle.style.fill = level === 2 ? "var(--high)" : level === 1 ? "var(--watch)" : "var(--normal)";
        circle.querySelector && null;
        circle.setAttributeNS(null, "data-pressure", reading[zone].pressure_kpa);
        circle.innerHTML = `<title>${ZONE_LABELS_AR[zone]}: ${reading[zone].pressure_kpa} kPa | ${reading[zone].temp_c}°C</title>`;
      });
    });

    // Gait
    const gait = data.gait || {};
    const l = gait.left || {}, r = gait.right || {};
    document.getElementById("stepsLeft").textContent = l.steps ?? "-";
    document.getElementById("stepsRight").textContent = r.steps ?? "-";
    document.getElementById("cadence").textContent = r.cadence ?? l.cadence ?? "-";
    const sym = (l.steps && r.steps) ? Math.abs(l.steps - r.steps) : 0;
    document.getElementById("symmetry").textContent = sym;
    document.getElementById("avoidanceNote").textContent =
      (l.avoidance || r.avoidance) ? "⚠️ ملاحظة: المريض بيتجنب الحمل على إحدى الرجلين" : "";

    // Alerts
    const list = document.getElementById("alertsList");
    if (data.alerts && data.alerts.length) {
      list.innerHTML = data.alerts.map(a =>
        `<li>${a.message}<span class="time">${a.t}</span></li>`).join("");
    } else {
      list.innerHTML = `<li class="empty">مفيش تنبيهات لسه</li>`;
    }
  } catch (e) {
    document.getElementById("statusDot").classList.remove("live");
    document.getElementById("statusText").textContent = "مفيش اتصال بالسيرفر...";
  }
}

async function refreshChart() {
  const zone = document.getElementById("zoneSelect").value;
  const [leftRes, rightRes] = await Promise.all([
    fetch(`/api/history?foot=left&zone=${zone}`), fetch(`/api/history?foot=right&zone=${zone}`),
  ]);
  const left = await leftRes.json(), right = await rightRes.json();
  const labels = left.map(p => p.t.split("T")[1] || p.t);
  tempChart.data.labels = labels;
  tempChart.data.datasets[0].data = left.map(p => p.temp);
  tempChart.data.datasets[1].data = right.map(p => p.temp);
  tempChart.update("none");
}

document.addEventListener("DOMContentLoaded", () => {
  buildFootSvg(document.getElementById("svg-left"));
  buildFootSvg(document.getElementById("svg-right"));
  populateZoneSelect();
  buildChart();
  document.getElementById("zoneSelect").addEventListener("change", refreshChart);

  setInterval(refreshHeatmaps, 2000);
  setInterval(refreshChart, 2000);
  refreshHeatmaps(); refreshChart();
});
