# -*- coding: utf-8 -*-
"""
Smart Diabetic Foot Monitor — Server
=====================================
سيرفر بسيط بيستقبل بيانات النعل الذكي (ضغط + حرارة + حركة)، يشغل عليها منطق
تصنيف خطورة مبدئي (بديل مؤقت لموديل الـ ML اللي هيتدرب بعدين)، ويعرض داشبورد حي.

تشغيل:
    pip install -r requirements.txt
    python app.py
ثم افتح المتصفح على: http://localhost:5000
"""

from flask import Flask, request, jsonify, render_template
from collections import deque
from datetime import datetime
import threading

app = Flask(__name__)
lock = threading.Lock()

# ---------------------------------------------------------------------------
# إعدادات عامة
# ---------------------------------------------------------------------------

# 8 مناطق في كل رجل (زي الأبحاث: الكعب، منتصف القدم الجانبي والداخلي، وتحت الأصابع الخمسة)
ZONES = ["heel", "medial_mid", "lateral_mid", "mt1", "mt2", "mt3", "mt4", "mt5"]
FEET = ["left", "right"]

# حدود التصنيف (Thresholds) — قيم مبدئية هنظبطها لما الموديل الحقيقي يتدرب
PRESSURE_WATCH_KPA = 200
PRESSURE_HIGH_KPA = 300
TEMP_DIFF_WATCH_C = 1.0   # الحد الطبيعي بين الرجلين
TEMP_DIFF_HIGH_C = 2.2    # الرقم اللي الأبحاث بتقول إنه غير طبيعي
PERSISTENCE_STREAK = 8    # لو نفس المنطقة فضلت "تحت الملاحظة" لعدد قراءات متتالي كده -> ترقية لخطر عالي
HISTORY_LEN = 300         # عدد القراءات المحفوظة لكل منطقة (للرسم البياني)

# ---------------------------------------------------------------------------
# تخزين مؤقت في الذاكرة (In-memory store) — بديل بسيط لقاعدة بيانات
# ---------------------------------------------------------------------------

history = {
    foot: {zone: deque(maxlen=HISTORY_LEN) for zone in ZONES} for foot in FEET
}
latest_reading = {foot: {} for foot in FEET}
watch_streak = {foot: {zone: 0 for zone in ZONES} for foot in FEET}
gait_history = deque(maxlen=HISTORY_LEN)
alerts_log = deque(maxlen=50)


def classify_zone(foot, zone, pressure, temp_self, temp_other, gait_avoidance_flag):
    """
    يدمج (Sensor Fusion) نتائج الضغط + الحرارة + المشي، ويطلع تصنيف واحد:
    0 = طبيعي (Normal) | 1 = تحت الملاحظة (Watch) | 2 = خطر عالي (High Risk)
    """
    # 1) مستوى الضغط
    if pressure >= PRESSURE_HIGH_KPA:
        pressure_level = 2
    elif pressure >= PRESSURE_WATCH_KPA:
        pressure_level = 1
    else:
        pressure_level = 0

    # 2) مستوى فرق الحرارة بين نفس المنطقة في الرجلين
    temp_diff = abs(temp_self - temp_other)
    if temp_diff >= TEMP_DIFF_HIGH_C:
        temp_level = 2
    elif temp_diff >= TEMP_DIFF_WATCH_C:
        temp_level = 1
    else:
        temp_level = 0

    level = max(pressure_level, temp_level)

    # 3) تعديل بناءً على تحليل المشي: لو المريض بيتجنب الحمل على نفس الرجل دي
    if gait_avoidance_flag and level == 1:
        level = 2

    # 4) الاستمرارية: لو "تحت الملاحظة" فضلت متكررة كتير -> ترقية لخطر عالي
    key_streak = watch_streak[foot][zone]
    if level == 1:
        key_streak += 1
        if key_streak >= PERSISTENCE_STREAK:
            level = 2
    else:
        key_streak = 0
    watch_streak[foot][zone] = key_streak

    return {
        "level": level,
        "label": {0: "normal", 1: "watch", 2: "high"}[level],
        "pressure_kpa": round(pressure, 1),
        "temp_c": round(temp_self, 2),
        "temp_diff_c": round(temp_diff, 2),
    }


@app.route("/")
def dashboard():
    return render_template("index.html")


@app.route("/api/ingest", methods=["POST"])
def ingest():
    """
    المحاكي (أو النعل الحقيقي لاحقًا) بيبعت هنا قراءة كاملة كل فترة زمنية:
    {
      "timestamp": "...",
      "left":  {"zones": {"heel": {"pressure": .., "temp": ..}, ...}, "gait": {...}},
      "right": {"zones": {...}, "gait": {...}}
    }
    """
    data = request.get_json(force=True)
    ts = data.get("timestamp") or datetime.utcnow().isoformat()

    with lock:
        # نحسب الفرق الحراري بالمقارنة بالرجل التانية في نفس المنطقة
        classified = {"left": {}, "right": {}}
        for foot in FEET:
            other = "right" if foot == "left" else "left"
            gait_flag = data.get(foot, {}).get("gait", {}).get("avoidance", False)
            for zone in ZONES:
                z_self = data.get(foot, {}).get("zones", {}).get(zone, {})
                z_other = data.get(other, {}).get("zones", {}).get(zone, {})
                pressure = float(z_self.get("pressure", 0))
                temp_self = float(z_self.get("temp", 32.0))
                temp_other = float(z_other.get("temp", 32.0))

                result = classify_zone(foot, zone, pressure, temp_self, temp_other, gait_flag)
                classified[foot][zone] = result

                history[foot][zone].append({
                    "t": ts, "pressure": result["pressure_kpa"],
                    "temp": result["temp_c"], "level": result["level"],
                })

                if result["level"] == 2:
                    alerts_log.appendleft({
                        "t": ts, "foot": foot, "zone": zone,
                        "message": f"خطر عالي في منطقة {zone} ({'يمين' if foot=='right' else 'شمال'})",
                    })

            latest_reading[foot] = classified[foot]

        gait_entry = {
            "t": ts,
            "left": data.get("left", {}).get("gait", {}),
            "right": data.get("right", {}).get("gait", {}),
        }
        gait_history.append(gait_entry)

    return jsonify({"status": "ok"})


@app.route("/api/latest")
def api_latest():
    with lock:
        return jsonify({
            "reading": latest_reading,
            "gait": gait_history[-1] if gait_history else {},
            "alerts": list(alerts_log)[:10],
        })


@app.route("/api/history")
def api_history():
    foot = request.args.get("foot", "left")
    zone = request.args.get("zone", "heel")
    with lock:
        return jsonify(list(history.get(foot, {}).get(zone, [])))


@app.route("/api/gait_history")
def api_gait_history():
    with lock:
        return jsonify(list(gait_history))


if __name__ == "__main__":
    app.run(debug=True, port=5000)
