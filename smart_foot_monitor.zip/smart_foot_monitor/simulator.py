# -*- coding: utf-8 -*-
"""
Smart Diabetic Foot Monitor — Simulator
========================================
بيمثّل النعل الذكي: بيولّد قراءات واقعية لضغط وحرارة وحركة المريض وهو ماشي،
وبيبعتها للسيرفر كل ثانيتين. فيه سيناريو "قرحة بتتطور بالتدريج" في منطقة mt3
بالرجل اليمين، عشان تشوف الداشبورد بيتفاعل ويرفع مستوى الخطورة تدريجيًا.
"""

import time
import math
import random
import requests

SERVER_URL = "http://localhost:5000/api/ingest"
ZONES = ["heel", "medial_mid", "lateral_mid", "mt1", "mt2", "mt3", "mt4", "mt5"]

# قيم أساسية طبيعية لكل منطقة (kPa للضغط، °C للحرارة)
BASE_PRESSURE = {
    "heel": 180, "medial_mid": 70, "lateral_mid": 60,
    "mt1": 140, "mt2": 130, "mt3": 130, "mt4": 110, "mt5": 100,
}
BASE_TEMP = 32.5

tick = 0
steps_total = {"left": 0, "right": 0}

# سيناريو التدهور: بعد كام قراءة تبدأ منطقة mt3 اليمين تتزود ضغط وحرارة بالتدريج
ANOMALY_START_TICK = 15
ANOMALY_ZONE = "mt3"
ANOMALY_FOOT = "right"


def walking_wave(base, t, phase=0.0, noise=6.0):
    """موجة بسيطة تحاكي دورة المشي (وقوف/رفع القدم) + تشويش عشوائي طبيعي."""
    wave = base + 25 * math.sin(t * 0.6 + phase)
    return max(0, wave + random.uniform(-noise, noise))


def build_reading():
    global tick
    tick += 1
    anomaly_progress = max(0, tick - ANOMALY_START_TICK)  # بيكبر مع الوقت بعد بداية السيناريو

    reading = {"timestamp": time.strftime("%Y-%m-%dT%H:%M:%S")}

    for foot, phase in (("left", 0.0), ("right", math.pi / 2)):
        zones_data = {}
        gait_avoidance = False

        for zone in ZONES:
            pressure = walking_wave(BASE_PRESSURE[zone], tick, phase)
            temp = BASE_TEMP + random.uniform(-0.3, 0.3)

            # تطبيق سيناريو التدهور التدريجي على المنطقة المستهدفة
            if foot == ANOMALY_FOOT and zone == ANOMALY_ZONE and anomaly_progress > 0:
                pressure += min(160, anomaly_progress * 6)   # ضغط بيزيد بالتدريج
                temp += min(3.0, anomaly_progress * 0.12)     # حرارة بتزيد بالتدريج
                if anomaly_progress > 20:
                    gait_avoidance = True  # المريض بدأ "يحمّل" على الرجل التانية لا-وعويًا

            zones_data[zone] = {"pressure": round(pressure, 1), "temp": round(temp, 2)}

        steps_total[foot] += random.randint(1, 2)
        reading[foot] = {
            "zones": zones_data,
            "gait": {
                "steps": steps_total[foot],
                "cadence": round(95 + random.uniform(-5, 5), 1),
                "avoidance": gait_avoidance,
            },
        }

    return reading


def main():
    print("🦶 المحاكي شغال... بيبعت بيانات كل ثانيتين إلى", SERVER_URL)
    print("   (اضغط Ctrl+C للإيقاف)")
    while True:
        payload = build_reading()
        try:
            requests.post(SERVER_URL, json=payload, timeout=3)
            print(f"tick {tick}: تم إرسال قراءة جديدة", end="\r")
        except requests.exceptions.ConnectionError:
            print("⚠️  السيرفر مش شغال. شغّل app.py الأول.")
        time.sleep(2)


if __name__ == "__main__":
    main()
